extends Node2D
# ============================================================
#  WARUNG TENGAH MALAM  -  Game Warung Anomali (Godot 4.x)
#  Semua visual digambar lewat kode (_draw) -> tanpa aset luar.
#  Ganti fungsi draw_person() / draw_pack() dst. dengan Sprite2D
#  kalau nanti mau pakai gambar sendiri.
# ============================================================

const W := 1280
const H := 720
const CX := 640.0
const COUNTER_Y := 440.0
const FLASH_MAX := 10.0
const MAX_NIGHT := 5
const CUST_RECT := Rect2(500, 70, 280, 372)
const B_FLASH := Rect2(335, 660, 200, 46)
const B_REJECT := Rect2(545, 660, 200, 46)
const B_NOTES := Rect2(755, 660, 200, 46)

enum S { TITLE, NIGHT_INTRO, PLAY, NIGHT_END, GAME_OVER, WIN }

# ---------------- DATA ----------------
var PRODUCTS := {
	"taro": {"name": "Keripik Taro", "price": 2000, "kind": "pack", "col": Color(0.18, 0.62, 0.31), "lab": "Taro"},
	"cihato": {"name": "Keripik Cihato", "price": 2500, "kind": "pack", "col": Color(0.95, 0.55, 0.12), "lab": "Cihato"},
	"qtila": {"name": "Keripik Qtila", "price": 2000, "kind": "pack", "col": Color(0.78, 0.12, 0.15), "lab": "Qtila"},
	"nesco": {"name": "Kopi Nesco", "price": 1500, "kind": "pack", "col": Color(0.32, 0.18, 0.12), "lab": "Nesco"},
	"permen": {"name": "Permen Toples", "price": 500, "kind": "jar", "col": Color(0.9, 0.3, 0.5), "lab": ""},
	"mie": {"name": "Mie Instan Indomi", "price": 3500, "kind": "mie", "col": Color(0.95, 0.78, 0.1), "lab": "Indomi"},
	"telur": {"name": "Telur", "price": 2500, "kind": "telur", "col": Color(0.96, 0.84, 0.66), "lab": ""},
	"biskuit": {"name": "Biskuit Roma", "price": 3000, "kind": "biskuit", "col": Color(0.2, 0.4, 0.8), "lab": "Roma"},
	"susu": {"name": "Susu Kotak", "price": 4000, "kind": "susu", "col": Color(0.3, 0.5, 0.9), "lab": "Susu"},
	"air": {"name": "Air Mineral Aquo", "price": 3000, "kind": "bottle", "col": Color(0.62, 0.84, 1.0), "cap": Color(0.1, 0.3, 0.8), "labc": Color(0.1, 0.45, 0.95), "lab": "Aquo"},
	"teh": {"name": "Teh Botol", "price": 4000, "kind": "bottle", "col": Color(0.55, 0.3, 0.1), "cap": Color(0.1, 0.5, 0.2), "labc": Color(0.9, 0.9, 0.85), "lab": "Teh"},
	"jeruk": {"name": "Jus Jeruk", "price": 4000, "kind": "bottle", "col": Color(1.0, 0.65, 0.1), "cap": Color(1.0, 0.4, 0.0), "labc": Color(1.0, 0.95, 0.8), "lab": "Jeruk"},
	"cola": {"name": "Kola-Kola", "price": 5000, "kind": "bottle", "col": Color(0.25, 0.1, 0.08), "cap": Color(0.85, 0.1, 0.1), "labc": Color(0.85, 0.1, 0.1), "lab": "Kola"},
	"sprit": {"name": "Spirit Lemon", "price": 5000, "kind": "bottle", "col": Color(0.4, 0.85, 0.35), "cap": Color(0.1, 0.6, 0.2), "labc": Color(0.15, 0.55, 0.2), "lab": "Spirit"},
}

var ANOM := {
	"tinggi": {"night": 1, "hint": "Lehernya terlalu panjang."},
	"senyum": {"night": 1, "hint": "Senyumnya terlalu lebar, sampai ke telinga."},
	"polos": {"night": 1, "hint": "Wajahnya kosong: tanpa mata dan mulut."},
	"tanpa_bayangan": {"night": 2, "hint": "Tidak punya bayangan di dinding."},
	"bayangan_aneh": {"night": 2, "hint": "Bayangannya bertanduk / bentuknya beda."},
	"melayang": {"night": 3, "hint": "Badannya melayang naik-turun, bayangannya diam."},
	"mata_merah": {"night": 3, "hint": "Matanya merah (pakai senter / kadang berkedip)."},
	"bayar_daun": {"night": 3, "hint": "Bayar pakai daun kering atau abu, bukan uang."},
	"permintaan": {"night": 4, "hint": "Minta barang aneh: nama, umur, suara..."},
}

var CREEPY := [
	"Ada yang jual... namamu, Bang?",
	"Aku mau beli... suara tawamu.",
	"Kemarin kamu bilang aku tak boleh masuk. Sekarang aku sudah di dalam.",
	"Jual sisa umurmu satu... berapa harganya?",
	"Aku cari seseorang yang wajahnya mirip kamu. Dia sudah mati.",
	"Satu bungkus... kesendirian, Bang.",
]

# ---------------- STATE ----------------
var state: int = S.TITLE
var night := 1
var money := 0
var sanity := 3
var complaints := 0
var handled := 0
var total := 8
var night_start_money := 0
var spawn_cd := 2.0
var cust = null
var held := ""
var flash_on := false
var flash_e := FLASH_MAX
var show_notes := false
var time := 0.0
var mouse := Vector2.ZERO
var toast_text := ""
var toast_col := Color.WHITE
var toast_t := 0.0
var scare_t := 0.0
var shake := 0.0
var go_after_scare := false
var over_reason := ""
var drawer_timer := 0.0
var drawer_amt := 0.0
var flick := 0.0
var flick_cd := 3.0
var slots: Array = []


func _ready() -> void:
	randomize()
	build_slots()


func build_slots() -> void:
	slots.clear()
	var ids := ["taro", "cihato", "qtila", "nesco"]
	for i in range(11):
		for r in range(3):
			slots.append({"id": ids[i % 4], "rect": Rect2(330 + i * 58, 52 + r * 60, 52, 56)})
	slots.append({"id": "permen", "rect": Rect2(425, 372, 72, 70)})
	slots.append({"id": "mie", "rect": Rect2(40, 212, 125, 88)})
	slots.append({"id": "telur", "rect": Rect2(175, 222, 115, 78)})
	slots.append({"id": "biskuit", "rect": Rect2(40, 352, 125, 88)})
	slots.append({"id": "susu", "rect": Rect2(175, 357, 115, 83)})
	var fr := ["air", "teh", "jeruk", "cola", "sprit"]
	for i in range(5):
		slots.append({"id": fr[i], "rect": Rect2(1005, 58 + i * 128, 240, 98)})


# ============================================================
#  GAME FLOW
# ============================================================
func new_game() -> void:
	night = 1
	money = 0
	sanity = 3
	start_night()


func start_night() -> void:
	handled = 0
	total = 6 + night * 2
	complaints = 0
	flash_e = FLASH_MAX
	flash_on = false
	night_start_money = money
	cust = null
	held = ""
	spawn_cd = 2.0
	show_notes = false
	state = S.NIGHT_INTRO


func pick_anoms() -> Array:
	var pool: Array = []
	for k in ANOM:
		if int(ANOM[k]["night"]) <= night:
			pool.append(k)
	var res: Array = []
	var first: String = pool.pick_random()
	res.append(first)
	if night >= 4 and randf() < 0.4:
		var second: String = pool.pick_random()
		var conflict: bool = (first == "tanpa_bayangan" and second == "bayangan_aneh") or (first == "bayangan_aneh" and second == "tanpa_bayangan")
		if second != first and not conflict:
			res.append(second)
	return res


func make_customer() -> Dictionary:
	var c := {}
	c["skin"] = [Color(0.96, 0.80, 0.66), Color(0.85, 0.65, 0.48), Color(0.70, 0.50, 0.35), Color(0.55, 0.38, 0.27)].pick_random()
	c["shirt"] = [Color(0.8, 0.2, 0.2), Color(0.2, 0.45, 0.75), Color(0.25, 0.55, 0.35), Color(0.85, 0.7, 0.2), Color(0.5, 0.3, 0.6), Color(0.3, 0.3, 0.35)].pick_random()
	c["hair"] = [Color(0.1, 0.08, 0.08), Color(0.25, 0.15, 0.08), Color(0.4, 0.25, 0.12)].pick_random()
	c["style"] = randi() % 4
	c["mask"] = randf() < 0.12
	var anoms: Array = []
	if randf() < 0.35 + 0.06 * night:
		anoms = pick_anoms()
	if handled == 0 and night == 1:
		anoms = []
	if anoms.has("polos") or anoms.has("senyum"):
		c["mask"] = false
	c["anoms"] = anoms
	var keys: Array = PRODUCTS.keys()
	var want: String = keys.pick_random()
	var pname: String = PRODUCTS[want]["name"]
	var line := ""
	if anoms.has("permintaan"):
		want = ""
		line = CREEPY.pick_random()
	else:
		var tpl: String = ["Bang, beli %s satu.", "Permisi, ada %s?", "%s satu ya, Bang.", "Malam-malam masih buka ya... Beli %s dong."].pick_random()
		line = tpl % pname
	c["want"] = want
	c["say"] = line
	c["pay"] = "uang"
	if anoms.has("bayar_daun"):
		c["pay"] = ["daun", "abu"].pick_random()
	c["pmax"] = maxf(14.0, 30.0 - night * 2.5)
	c["patience"] = c["pmax"]
	c["t"] = 0.0
	c["out_t"] = 0.0
	c["st"] = "in"
	c["reveal"] = false
	return c


func toast(s: String, col: Color = Color.WHITE) -> void:
	toast_text = s
	toast_col = col
	toast_t = 3.0


func scare(msg: String) -> void:
	sanity -= 1
	scare_t = 0.9
	shake = 1.0
	toast(msg, Color(1, 0.35, 0.35))
	if sanity <= 0:
		go_after_scare = true
		over_reason = "Kewarasanmu habis. Warung itu kini milik mereka..."


func give(item: String) -> void:
	var c: Dictionary = cust
	held = ""
	var anoms: Array = c["anoms"]
	if anoms.size() > 0:
		c["say"] = ""
		c["st"] = "out"
		c["out_t"] = 0.0
		scare("Kamu memberi barang pada ANOMALI!")
	elif item == c["want"]:
		var price: int = PRODUCTS[item]["price"]
		money += price
		toast("+%s  (%s)" % [rp(price), PRODUCTS[item]["name"]], Color(0.6, 1, 0.6))
		c["say"] = ["Makasih, Bang!", "Pas ya, Bang. Makasih.", "Sip, Bang. Saya pamit."].pick_random()
		c["st"] = "out"
		c["out_t"] = -0.9
		drawer_timer = 1.4
	else:
		c["patience"] = float(c["patience"]) - 6.0
		c["say"] = ["Bukan itu, Bang...", "Eh, salah, Bang. Yang tadi saya bilang.", "Lho, bukan ini."].pick_random()
		toast("Barang salah! Pelanggan makin tidak sabar.", Color(1, 0.8, 0.3))


func reject() -> void:
	if cust == null:
		return
	var c: Dictionary = cust
	if c["st"] != "wait":
		return
	held = ""
	var anoms: Array = c["anoms"]
	if anoms.size() > 0:
		money += 2000
		toast("Anomali berhasil diusir!  +Rp2.000", Color(0.6, 1, 0.6))
		c["say"] = ""
		c["st"] = "out"
		c["out_t"] = 0.0
	else:
		money = maxi(0, money - 3000)
		complaints += 1
		toast("Kamu mengusir pelanggan NORMAL! Komplain +1, -Rp3.000", Color(1, 0.5, 0.4))
		c["say"] = "Dih, kok diusir sih?!"
		c["st"] = "out"
		c["out_t"] = -0.8
		if complaints >= 3:
			over_reason = "Warga mengeluh terus. Warungmu ditutup."
			state = S.GAME_OVER


func on_timeout(c: Dictionary) -> void:
	var anoms: Array = c["anoms"]
	if anoms.size() > 0:
		c["say"] = ""
		c["st"] = "out"
		c["out_t"] = 0.0
		scare("Makhluk itu menatapmu terlalu lama...")
	else:
		money = maxi(0, money - 1000)
		toast("Pelanggan kesal menunggu lama. -Rp1.000", Color(1, 0.8, 0.3))
		c["say"] = "Lama banget, ah!"
		c["st"] = "out"
		c["out_t"] = -0.6


func toggle_flash() -> void:
	if flash_on:
		flash_on = false
	elif flash_e > 0.5:
		flash_on = true


# ============================================================
#  INPUT & UPDATE
# ============================================================
func _input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_LEFT:
			on_click(get_global_mouse_position())
		elif e.button_index == MOUSE_BUTTON_RIGHT:
			held = ""
	elif e is InputEventKey and e.pressed and not e.echo and state == S.PLAY:
		match e.keycode:
			KEY_F:
				toggle_flash()
			KEY_X:
				reject()
			KEY_N:
				show_notes = not show_notes
			KEY_ESCAPE:
				held = ""
				show_notes = false


func on_click(p: Vector2) -> void:
	if scare_t > 0.0:
		return
	match state:
		S.TITLE:
			new_game()
		S.NIGHT_INTRO:
			state = S.PLAY
		S.NIGHT_END:
			if night >= MAX_NIGHT:
				state = S.WIN
			else:
				night += 1
				start_night()
		S.GAME_OVER, S.WIN:
			state = S.TITLE
		S.PLAY:
			play_click(p)


func play_click(p: Vector2) -> void:
	if show_notes:
		show_notes = false
		return
	if B_FLASH.has_point(p):
		toggle_flash()
		return
	if B_REJECT.has_point(p):
		reject()
		return
	if B_NOTES.has_point(p):
		show_notes = true
		return
	if held != "" and cust != null and CUST_RECT.has_point(p):
		var c: Dictionary = cust
		if c["st"] == "wait":
			give(held)
		return
	for s in slots:
		if s["rect"].has_point(p):
			held = s["id"]
			return


func _process(delta: float) -> void:
	time += delta
	mouse = get_global_mouse_position()
	toast_t = maxf(0.0, toast_t - delta)
	shake = maxf(0.0, shake - delta * 1.4)
	if scare_t > 0.0:
		scare_t -= delta
		if scare_t <= 0.0 and go_after_scare:
			go_after_scare = false
			state = S.GAME_OVER
	drawer_timer = maxf(0.0, drawer_timer - delta)
	drawer_amt = move_toward(drawer_amt, 1.0 if drawer_timer > 0.0 else 0.0, delta * 5.0)
	flick = maxf(0.0, flick - delta)
	flick_cd -= delta
	if flick_cd <= 0.0:
		flick = randf_range(0.08, 0.25)
		var here: bool = false
		if cust != null:
			here = (cust["anoms"] as Array).size() > 0
		flick_cd = randf_range(2.0, 6.0) * (0.45 if here else 1.0)
	if state == S.PLAY:
		update_play(delta)
	queue_redraw()


func update_play(delta: float) -> void:
	if flash_on:
		flash_e -= delta
		if flash_e <= 0.0:
			flash_e = 0.0
			flash_on = false
	else:
		flash_e = minf(FLASH_MAX, flash_e + delta * 0.6)
	if cust == null:
		if handled >= total:
			state = S.NIGHT_END
		else:
			spawn_cd -= delta
			if spawn_cd <= 0.0:
				cust = make_customer()
		return
	var c: Dictionary = cust
	c["t"] = float(c["t"]) + delta
	match c["st"]:
		"in":
			if c["t"] >= 1.0:
				c["st"] = "wait"
		"wait":
			var anoms: Array = c["anoms"]
			var hp := Vector2(CX, 250.0 - (95.0 if anoms.has("tinggi") else 0.0))
			c["reveal"] = flash_on and mouse.distance_to(hp) < 150.0
			c["patience"] = float(c["patience"]) - delta
			if c["patience"] <= 0.0:
				on_timeout(c)
		"out":
			c["reveal"] = false
			c["out_t"] = float(c["out_t"]) + delta
			if c["out_t"] >= 0.7:
				cust = null
				handled += 1
				spawn_cd = 1.3
				held = ""


# ============================================================
#  HELPERS
# ============================================================
func rp(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "." + out
	return ("-" if n < 0 else "") + "Rp" + out


func clock_str() -> String:
	var frac: float = float(handled) / float(maxi(total, 1))
	var m: int = int(22 * 60 + frac * 7.0 * 60.0) % 1440
	return "%02d:%02d" % [int(m / 60.0), m % 60]


func sc(col: Color, sh: bool) -> Color:
	return Color(0, 0, 0, 0.5) if sh else col


func ell_pts(c: Vector2, rx: float, ry: float, a0: float = 0.0, a1: float = TAU, n: int = 28) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var full: bool = absf(a1 - a0) >= TAU - 0.001
	var cnt: int = n if full else n + 1
	for i in range(cnt):
		var a: float = a0 + (a1 - a0) * float(i) / float(n)
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func ell(c: Vector2, rx: float, ry: float, col: Color) -> void:
	draw_colored_polygon(ell_pts(c, rx, ry), col)


func rr(r: Rect2, col: Color, rad: int = 8, bcol: Color = Color(0, 0, 0, 0), bw: int = 0) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(rad)
	if bw > 0:
		sb.border_color = bcol
		sb.set_border_width_all(bw)
	draw_style_box(sb, r)


func tx(p: Vector2, s: String, size: int = 18, col: Color = Color.WHITE, al: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, w: float = -1.0, shadow: bool = true) -> void:
	var f := ThemeDB.fallback_font
	if shadow:
		draw_string(f, p + Vector2(1, 1.5), s, al, w, size, Color(0, 0, 0, 0.75))
	draw_string(f, p, s, al, w, size, col)


func ctext(y: float, s: String, size: int = 20, col: Color = Color.WHITE) -> void:
	tx(Vector2(0, y), s, size, col, HORIZONTAL_ALIGNMENT_CENTER, W)


func heart(c: Vector2, s: float, col: Color) -> void:
	draw_circle(c + Vector2(-s * 0.5, -s * 0.2), s * 0.55, col)
	draw_circle(c + Vector2(s * 0.5, -s * 0.2), s * 0.55, col)
	draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 1.02, 0.0), c + Vector2(s * 1.02, 0.0), c + Vector2(0, s * 1.3)]), col)


# ============================================================
#  DRAWING - PRODUK
# ============================================================
func draw_pack(r: Rect2, p: Dictionary) -> void:
	var col: Color = p["col"]
	draw_rect(r, col)
	draw_rect(Rect2(r.position, Vector2(r.size.x, 6)), col.lightened(0.35))
	draw_rect(Rect2(r.position + Vector2(0, r.size.y - 5), Vector2(r.size.x, 5)), col.lightened(0.35))
	draw_rect(Rect2(r.position + Vector2(5, 10), Vector2(4, r.size.y - 20)), Color(1, 1, 1, 0.25))
	draw_rect(r, col.darkened(0.55), false, 1.5)
	var lab: String = p["lab"]
	if lab != "":
		ell(r.position + Vector2(r.size.x * 0.5, r.size.y * 0.5), r.size.x * 0.4, r.size.y * 0.2, Color(1, 1, 1, 0.92))
		draw_string(ThemeDB.fallback_font, Vector2(r.position.x, r.position.y + r.size.y * 0.5 + 4), lab, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 11, col.darkened(0.6))


func draw_bottle(r: Rect2, p: Dictionary) -> void:
	var col: Color = p["col"]
	var body := Rect2(r.position.x, r.position.y + r.size.y * 0.28, r.size.x, r.size.y * 0.72)
	rr(body, col, 5)
	draw_rect(Rect2(r.position.x + r.size.x * 0.3, r.position.y + r.size.y * 0.08, r.size.x * 0.4, r.size.y * 0.24), col)
	draw_rect(Rect2(r.position.x + r.size.x * 0.25, r.position.y, r.size.x * 0.5, r.size.y * 0.1), p["cap"])
	draw_rect(Rect2(r.position.x + 1, r.position.y + r.size.y * 0.5, r.size.x - 2, r.size.y * 0.22), p["labc"])
	draw_rect(Rect2(r.position.x + 4, r.position.y + r.size.y * 0.32, 3, r.size.y * 0.6), Color(1, 1, 1, 0.35))


func draw_jar(r: Rect2) -> void:
	for i in range(16):
		var pos := Vector2(r.position.x + 12 + float((i * 13) % 46), r.position.y + 24 + float((i * 7) % 38))
		draw_circle(pos, 5.0, Color.from_hsv(float(i) / 16.0, 0.75, 1.0))
	rr(Rect2(r.position + Vector2(4, 12), Vector2(r.size.x - 8, r.size.y - 12)), Color(0.8, 0.9, 1, 0.22), 8, Color(0.85, 0.93, 1, 0.85), 2)
	draw_rect(Rect2(r.position.x + 10, r.position.y, r.size.x - 20, 14), Color(0.8, 0.12, 0.12))


func draw_bin(r: Rect2, p: Dictionary) -> void:
	var cardb := Color(0.72, 0.52, 0.30)
	var kind: String = p["kind"]
	var col: Color = p["col"]
	draw_rect(Rect2(r.position + Vector2(0, r.size.y * 0.35), Vector2(r.size.x, r.size.y * 0.65)), cardb.darkened(0.3))
	match kind:
		"mie":
			for i in range(5):
				var rc := Rect2(r.position.x + 6 + i * 23, r.position.y + 2 + (i % 2) * 5, 28, r.size.y * 0.62)
				draw_pack(rc, {"col": col if i % 2 == 0 else Color(0.85, 0.2, 0.1), "lab": "Mi"})
		"telur":
			for i in range(6):
				ell(r.position + Vector2(16 + i * 18.0, r.size.y * 0.4 + (i % 2) * 7.0), 9, 12, col)
		"biskuit":
			for i in range(3):
				var rc := Rect2(r.position.x + 8 + i * 38, r.position.y + 3, 32, r.size.y * 0.66)
				draw_rect(rc, col)
				draw_rect(Rect2(rc.position.x, rc.position.y + rc.size.y * 0.35, rc.size.x, 12), Color(1, 1, 1, 0.85))
				draw_rect(rc, col.darkened(0.5), false, 1.5)
		"susu":
			for i in range(4):
				var rc := Rect2(r.position.x + 8 + i * 26, r.position.y + 8, 22, r.size.y * 0.6)
				draw_rect(rc, Color(0.95, 0.96, 1.0))
				draw_rect(Rect2(rc.position.x, rc.position.y + 14, rc.size.x, 16), col)
				draw_colored_polygon(PackedVector2Array([rc.position, rc.position + Vector2(rc.size.x, 0), rc.position + Vector2(rc.size.x * 0.5, -9)]), Color(0.85, 0.88, 0.95))
	draw_rect(Rect2(r.position + Vector2(0, r.size.y * 0.5), Vector2(r.size.x, r.size.y * 0.5)), cardb)
	draw_rect(Rect2(r.position + Vector2(0, r.size.y * 0.5), Vector2(r.size.x, r.size.y * 0.5)), cardb.darkened(0.5), false, 2)
	draw_rect(Rect2(r.position + Vector2(r.size.x * 0.5 - 12, r.size.y * 0.5), Vector2(24, 8)), cardb.darkened(0.2))
	draw_string(ThemeDB.fallback_font, r.position + Vector2(0, r.size.y * 0.5 + 28), p["name"], HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 12, Color(0.25, 0.14, 0.05))


func draw_icon(r: Rect2, id: String) -> void:
	var p: Dictionary = PRODUCTS[id]
	match p["kind"]:
		"bottle":
			draw_bottle(r, p)
		"jar":
			draw_jar(r)
		"telur":
			ell(r.get_center(), r.size.x * 0.4, r.size.y * 0.4, p["col"])
		_:
			draw_pack(r, p)


# ============================================================
#  DRAWING - LATAR
# ============================================================
func draw_bg() -> void:
	# dinding kayu hangat
	draw_rect(Rect2(0, 0, W, H), Color(0.40, 0.26, 0.15))
	draw_rect(Rect2(310, 0, 670, 640), Color(0.50, 0.34, 0.20))
	for x in range(340, 975, 66):
		draw_line(Vector2(x, 244), Vector2(x, 440), Color(0.35, 0.22, 0.12, 0.5), 2.0)
	# jaring kawat dinding
	draw_rect(Rect2(325, 44, 650, 200), Color(0.20, 0.20, 0.23))
	for x in range(325, 976, 16):
		draw_line(Vector2(x, 44), Vector2(x, 244), Color(0.52, 0.52, 0.58, 0.75), 1.0)
	for y in range(44, 245, 16):
		draw_line(Vector2(325, y), Vector2(975, y), Color(0.52, 0.52, 0.58, 0.75), 1.0)
	# rak kiri
	draw_rect(Rect2(0, 0, 310, H), Color(0.52, 0.33, 0.17))
	draw_rect(Rect2(28, 44, 282, H - 44), Color(0.17, 0.12, 0.09))
	for y in [160, 300, 440, 580]:
		draw_rect(Rect2(20, y, 290, 16), Color(0.76, 0.5, 0.26))
		draw_rect(Rect2(20, y + 16, 290, 5), Color(0.38, 0.23, 0.11))
	draw_rect(Rect2(28, 601, 282, 119), Color(0.3, 0.19, 0.1))
	for x in range(40, 300, 48):
		draw_line(Vector2(x, 601), Vector2(x, 720), Color(0.18, 0.1, 0.05), 3.0)
	# gagang rak
	draw_rect(Rect2(26, 66, 6, 40), Color(0.7, 0.7, 0.72))
	draw_rect(Rect2(26, 66, 22, 5), Color(0.7, 0.7, 0.72))
	draw_rect(Rect2(26, 101, 22, 5), Color(0.7, 0.7, 0.72))
	# dekorasi rak: snack atas & botol kecap bawah
	var deco := [Color(0.9, 0.7, 0.2), Color(0.2, 0.55, 0.3), Color(0.85, 0.25, 0.2), Color(0.3, 0.5, 0.8), Color(0.9, 0.5, 0.1), Color(0.6, 0.3, 0.6)]
	for i in range(6):
		draw_pack(Rect2(40 + i * 44, 96, 38, 62), {"col": deco[i], "lab": ""})
	var dids := ["cola", "jeruk", "teh", "sprit", "cola", "jeruk", "teh", "sprit"]
	for i in range(8):
		draw_bottle(Rect2(40 + i * 32, 500, 24, 78), PRODUCTS[dids[i]])
	# kulkas kanan
	draw_rect(Rect2(980, 0, 300, H), Color(0.08, 0.15, 0.5))
	draw_rect(Rect2(1000, 0, 250, H - 40), Color(0.78, 0.9, 1.0))
	draw_rect(Rect2(1222, 0, 28, H - 40), Color(1, 1, 1, 0.45))
	for i in range(5):
		draw_rect(Rect2(1000, 58 + i * 128 + 100, 250, 9), Color(0.55, 0.72, 0.95))
	draw_rect(Rect2(984, 250, 12, 160), Color(0.04, 0.09, 0.35))
	draw_rect(Rect2(980, H - 40, 300, 40), Color(0.05, 0.08, 0.25))
	# lantai
	draw_rect(Rect2(310, 640, 670, 80), Color(0.2, 0.12, 0.07))
	for x in range(310, 980, 60):
		draw_line(Vector2(x, 640), Vector2(x, 720), Color(0.1, 0.06, 0.03), 2.0)


func draw_slots() -> void:
	for s in slots:
		var p: Dictionary = PRODUCTS[s["id"]]
		var r: Rect2 = s["rect"]
		match p["kind"]:
			"pack":
				draw_pack(r, p)
			"bottle":
				for i in range(5):
					draw_bottle(Rect2(r.position.x + 8 + i * 46.0, r.position.y + 4, 26, 90), p)
			"jar":
				pass
			_:
				draw_bin(r, p)


func draw_counter() -> void:
	# permukaan
	draw_rect(Rect2(310, COUNTER_Y, 670, 22), Color(0.80, 0.54, 0.31))
	draw_rect(Rect2(310, COUNTER_Y, 670, 4), Color(0.92, 0.7, 0.45))
	# badan
	draw_rect(Rect2(310, COUNTER_Y + 22, 670, 190), Color(0.60, 0.38, 0.21))
	draw_rect(Rect2(310, COUNTER_Y + 22, 26, 190), Color(0.46, 0.28, 0.14))
	draw_rect(Rect2(954, COUNTER_Y + 22, 26, 190), Color(0.46, 0.28, 0.14))
	# laci kecil
	for i in range(5):
		var r := Rect2(352 + i * 120, 476, 100, 50)
		draw_rect(r, Color(0.33, 0.28, 0.28))
		draw_rect(r, Color(0.15, 0.12, 0.12), false, 2)
		draw_rect(Rect2(r.position.x + 28, r.position.y + 34, 44, 6), Color(0.15, 0.13, 0.13))
	# laci besar (bisa terbuka)
	var dy: float = 38.0 * drawer_amt
	if drawer_amt > 0.01:
		draw_colored_polygon(PackedVector2Array([Vector2(372, 546), Vector2(918, 546), Vector2(946, 546 + dy), Vector2(344, 546 + dy)]), Color(0.28, 0.18, 0.12))
		var bills := [Color(0.6, 0.8, 0.6), Color(0.6, 0.7, 0.95), Color(0.85, 0.6, 0.9), Color(0.95, 0.75, 0.6)]
		for i in range(4):
			draw_rect(Rect2(400 + i * 70, 548 + dy * 0.2, 56, dy * 0.7), bills[i])
		for i in range(5):
			draw_circle(Vector2(700 + i * 40, 548 + dy * 0.5), 8.0, Color(0.75, 0.75, 0.78))
	var fr := Rect2(348, 546 + dy, 596, 76)
	draw_rect(fr, Color(0.72, 0.46, 0.26))
	draw_rect(fr, Color(0.35, 0.2, 0.1), false, 3)
	draw_circle(Vector2(646, 584 + dy), 8.0, Color(0.75, 0.75, 0.78))
	draw_rect(Rect2(643, 584 + dy, 6, 12), Color(0.2, 0.2, 0.22))


func draw_counter_props() -> void:
	# kotak TOP
	rr(Rect2(335, 394, 82, 46), Color(0.2, 0.36, 0.78), 5, Color(0.1, 0.18, 0.5), 2)
	ell(Vector2(376, 405), 12, 6, Color(0.85, 0.92, 1.0))
	tx(Vector2(335, 432), "TOP", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 82)
	# toples permen
	draw_jar(Rect2(425, 372, 72, 70))
	# gelas pensil
	rr(Rect2(512, 398, 28, 42), Color(0.18, 0.15, 0.15), 3)
	for i in range(4):
		draw_line(Vector2(518 + i * 5, 398), Vector2(514 + i * 7, 380), Color.from_hsv(float(i) / 4.0, 0.8, 1.0), 3.0)
	# mesin kasir
	draw_rect(Rect2(560, 418, 76, 22), Color(0.1, 0.1, 0.12))
	draw_rect(Rect2(568, 421, 30, 8), Color(0.3, 0.9, 0.5))


func draw_payment(c: Dictionary) -> void:
	if c["st"] == "out" or float(c["t"]) < 0.9:
		return
	var pay: String = c["pay"]
	match pay:
		"uang":
			draw_rect(Rect2(690, 424, 64, 24), Color(0.72, 0.6, 0.86))
			draw_rect(Rect2(690, 424, 64, 24), Color(0.3, 0.2, 0.4), false, 1.5)
			draw_rect(Rect2(702, 416, 64, 24), Color(0.55, 0.68, 0.88))
			draw_rect(Rect2(702, 416, 64, 24), Color(0.2, 0.3, 0.5), false, 1.5)
			draw_circle(Vector2(734, 428), 6.0, Color(1, 1, 1, 0.6))
		"daun":
			for i in range(4):
				var lc := Color(0.5, 0.33, 0.12) if i % 2 == 0 else Color(0.38, 0.45, 0.12)
				ell(Vector2(698 + i * 17.0, 430 - (i % 2) * 5.0), 14, 7, lc)
				draw_line(Vector2(686 + i * 17.0, 430 - (i % 2) * 5.0), Vector2(710 + i * 17.0, 430 - (i % 2) * 5.0), lc.darkened(0.4), 1.0)
		"abu":
			ell(Vector2(722, 436), 34, 9, Color(0.5, 0.5, 0.5))
			ell(Vector2(722, 430), 20, 7, Color(0.62, 0.62, 0.62))
			for i in range(6):
				draw_circle(Vector2(700 + i * 9.0, 436 + (i % 2) * 2.0), 1.5, Color(0.25, 0.25, 0.25))


# ============================================================
#  DRAWING - ORANG
# ============================================================
func cust_yoff(c: Dictionary) -> float:
	if c["st"] == "in":
		return pow(1.0 - clampf(float(c["t"]) / 1.0, 0.0, 1.0), 2.0) * 300.0
	if c["st"] == "out":
		return pow(clampf(float(c["out_t"]) / 0.7, 0.0, 1.0), 2.0) * 330.0
	return 0.0


func draw_person(c: Dictionary, sh: bool, yoff: float) -> void:
	var anoms: Array = c["anoms"]
	var cx: float = CX + (215.0 if sh else 0.0)
	var by: float = COUNTER_Y + yoff + sin(time * 1.7) * 1.5
	if (not sh) and anoms.has("melayang"):
		by += sin(time * 1.6) * 18.0 - 12.0
	var tall: bool = anoms.has("tinggi")
	var hy: float = by - 190.0 - (95.0 if tall else 0.0)
	var weird: bool = sh and anoms.has("bayangan_aneh")
	if weird:
		hy -= 40.0
	var skin_raw: Color = c["skin"]
	var skin: Color = sc(skin_raw, sh)
	var shirt: Color = sc(c["shirt"], sh)
	var hair: Color = sc(c["hair"], sh)
	var cover: Color = sc((c["shirt"] as Color).lightened(0.3), sh)
	var style: int = c["style"]

	# rambut panjang (belakang)
	if style == 1:
		ell(Vector2(cx, hy - 2), 58, 56, hair)
		draw_rect(Rect2(cx - 58, hy - 2, 116, maxf(10.0, by - hy - 20.0)), hair)
	# leher
	draw_rect(Rect2(cx - 16, hy + 30, 32, (by - 125) - (hy + 30)), sc(skin_raw.darkened(0.1), sh))
	# badan
	draw_rect(Rect2(cx - 70, by - 135, 140, 230), shirt)
	draw_circle(Vector2(cx - 62, by - 106), 30.0, shirt)
	draw_circle(Vector2(cx + 62, by - 106), 30.0, shirt)
	draw_rect(Rect2(cx - 104, by - 108, 30, 100), shirt)
	draw_rect(Rect2(cx + 74, by - 108, 30, 100), shirt)
	draw_circle(Vector2(cx - 89, by - 4), 15.0, skin)
	draw_circle(Vector2(cx + 89, by - 4), 15.0, skin)
	if not sh:
		draw_rect(Rect2(cx - 70, by - 135, 16, 230), Color(0, 0, 0, 0.12))
		draw_rect(Rect2(cx + 54, by - 135, 16, 230), Color(1, 1, 1, 0.06))
		if style != 2:
			draw_colored_polygon(PackedVector2Array([Vector2(cx - 20, by - 135), Vector2(cx + 20, by - 135), Vector2(cx, by - 98)]), skin)
	# hijab (belakang)
	if style == 2:
		ell(Vector2(cx, hy + 6), 64, 62, cover)
		draw_colored_polygon(PackedVector2Array([Vector2(cx - 62, hy + 20), Vector2(cx + 62, hy + 20), Vector2(cx + 92, by - 95), Vector2(cx - 92, by - 95)]), cover)
	# kepala
	if style != 2:
		draw_circle(Vector2(cx - 47, hy + 6), 9.0, skin)
		draw_circle(Vector2(cx + 47, hy + 6), 9.0, skin)
	ell(Vector2(cx, hy), 40.0 if style == 2 else 48.0, 52.0, skin)
	# rambut depan / hijab depan
	if style == 2:
		draw_colored_polygon(ell_pts(Vector2(cx, hy - 4), 48, 54, PI, TAU, 24), cover)
		draw_rect(Rect2(cx - 50, hy - 6, 12, 56), cover)
		draw_rect(Rect2(cx + 38, hy - 6, 12, 56), cover)
	else:
		draw_colored_polygon(ell_pts(Vector2(cx, hy - 6), 52, 56, PI, TAU, 24), hair)
		draw_colored_polygon(PackedVector2Array([Vector2(cx - 52, hy - 6), Vector2(cx - 34, hy + 12), Vector2(cx - 18, hy - 2), Vector2(cx + 2, hy + 14), Vector2(cx + 22, hy - 2), Vector2(cx + 40, hy + 10), Vector2(cx + 52, hy - 6)]), hair)
		if style == 3:
			draw_colored_polygon(PackedVector2Array([Vector2(cx - 38, hy - 34), Vector2(cx + 38, hy - 34), Vector2(cx + 32, hy - 66), Vector2(cx - 32, hy - 66)]), sc(Color(0.07, 0.07, 0.09), sh))
			if not sh:
				draw_rect(Rect2(cx - 38, hy - 38, 76, 5), Color(0.85, 0.7, 0.2))
	# bayangan aneh: tanduk + mata kuning
	if weird:
		var hc := Color(0, 0, 0, 0.5)
		draw_colored_polygon(PackedVector2Array([Vector2(cx - 40, hy - 30), Vector2(cx - 62, hy - 90), Vector2(cx - 12, hy - 48)]), hc)
		draw_colored_polygon(PackedVector2Array([Vector2(cx + 40, hy - 30), Vector2(cx + 62, hy - 90), Vector2(cx + 12, hy - 48)]), hc)
		ell(Vector2(cx - 17, hy + 4), 9, 4, Color(1, 0.9, 0.3, 0.95))
		ell(Vector2(cx + 17, hy + 4), 9, 4, Color(1, 0.9, 0.3, 0.95))
	if sh:
		return
	# ---- wajah ----
	if anoms.has("polos"):
		return
	var red: bool = bool(c["reveal"]) or (anoms.has("mata_merah") and fmod(time, 5.0) < 0.13)
	for sgn in [-1.0, 1.0]:
		var ex: float = cx + sgn * 18.0
		var ey: float = hy + 6.0
		if red:
			draw_circle(Vector2(ex, ey), 17.0, Color(1, 0, 0, 0.25))
			ell(Vector2(ex, ey), 9, 12, Color(0.05, 0, 0))
			draw_circle(Vector2(ex, ey), 5.0, Color(1, 0.1, 0.1))
		else:
			ell(Vector2(ex, ey), 9, 11, Color.WHITE)
			ell(Vector2(ex, ey + 1), 6, 9, Color(0.18, 0.1, 0.08))
			draw_circle(Vector2(ex - 2, ey - 3), 2.5, Color.WHITE)
		draw_line(Vector2(ex - 11, ey - 17), Vector2(ex + 9, ey - 18), hair if style != 2 else Color(0.2, 0.12, 0.1), 3.0)
		ell(Vector2(cx + sgn * 30.0, hy + 24), 9, 5, Color(1, 0.5, 0.5, 0.33))
	draw_line(Vector2(cx, hy + 14), Vector2(cx + 2, hy + 20), skin_raw.darkened(0.2), 2.0)
	if c["mask"]:
		draw_colored_polygon(PackedVector2Array([Vector2(cx - 40, hy + 12), Vector2(cx + 40, hy + 12), Vector2(cx + 30, hy + 46), Vector2(cx, hy + 52), Vector2(cx - 30, hy + 46)]), Color(0.9, 0.93, 0.98))
		draw_line(Vector2(cx - 34, hy + 24), Vector2(cx + 34, hy + 24), Color(0.7, 0.75, 0.85), 1.5)
	elif anoms.has("senyum"):
		var pts := PackedVector2Array()
		for i in range(17):
			pts.append(Vector2(cx - 48 + i * 6.0, hy + 20 + 22.0 * sin(PI * float(i) / 16.0)))
		draw_colored_polygon(pts, Color(0.45, 0.02, 0.05))
		for i in range(1, 16):
			var tx_ := cx - 48 + i * 6.0
			draw_line(Vector2(tx_, hy + 21), Vector2(tx_, hy + 20 + 20.0 * sin(PI * float(i) / 16.0)), Color(1, 1, 0.9), 1.5)
		draw_polyline(pts, Color(0.2, 0, 0), 2.0)
	else:
		draw_polyline(PackedVector2Array([Vector2(cx - 9, hy + 27), Vector2(cx, hy + 32), Vector2(cx + 9, hy + 27)]), Color(0.5, 0.15, 0.15), 2.5)


func draw_bubble(c: Dictionary) -> void:
	var say: String = c["say"]
	if say == "" or float(c["t"]) < 1.0:
		return
	var f := ThemeDB.fallback_font
	var sz := f.get_multiline_string_size(say, HORIZONTAL_ALIGNMENT_LEFT, 205.0, 17)
	var r := Rect2(322, 258, 232, sz.y + 24)
	rr(r, Color(0.97, 0.95, 0.88), 12, Color(0.2, 0.15, 0.1), 3)
	draw_colored_polygon(PackedVector2Array([Vector2(r.end.x - 2, r.position.y + 16), Vector2(r.end.x + 26, r.position.y + 34), Vector2(r.end.x - 2, r.position.y + 46)]), Color(0.97, 0.95, 0.88))
	draw_multiline_string(f, Vector2(r.position.x + 14, r.position.y + 28), say, HORIZONTAL_ALIGNMENT_LEFT, 205.0, 17, -1, Color(0.1, 0.07, 0.07))
	if c["st"] == "wait":
		var frac: float = clampf(float(c["patience"]) / float(c["pmax"]), 0.0, 1.0)
		draw_rect(Rect2(r.position.x, r.end.y + 8, r.size.x, 8), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(r.position.x, r.end.y + 8, r.size.x * frac, 8), Color(0.35, 0.9, 0.4).lerp(Color(0.95, 0.2, 0.2), 1.0 - frac))


# ============================================================
#  DRAWING - UI
# ============================================================
func draw_scene() -> void:
	draw_bg()
	draw_slots()
	if cust != null:
		var c: Dictionary = cust
		var yo: float = cust_yoff(c)
		var anoms: Array = c["anoms"]
		if not anoms.has("tanpa_bayangan"):
			draw_person(c, true, yo)
		draw_person(c, false, yo)
	draw_counter()
	draw_counter_props()
	if cust != null:
		draw_payment(cust)


func draw_atmosphere() -> void:
	# gelap malam
	var a: float = 0.34 + (0.28 if flick > 0.0 else 0.0) + (0.12 if flash_on else 0.0)
	draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.02, 0.10, a))
	# cahaya lampu hangat dari atas
	if flick <= 0.0:
		for i in range(7):
			draw_circle(Vector2(CX, -30), 520.0 - i * 65.0, Color(1.0, 0.78, 0.42, 0.018))
	# kabut
	for i in range(5):
		var fx: float = 160.0 + i * 280.0 + sin(time * 0.3 + i) * 60.0
		ell(Vector2(fx, 700), 260, 40, Color(0.7, 0.75, 0.9, 0.05))
	# senter
	if flash_on:
		for i in range(18):
			draw_circle(mouse, 190.0 - i * 10.0, Color(1, 0.95, 0.7, 0.03))
	# vignette
	for i in range(8):
		draw_rect(Rect2(i * 14, i * 8, W - i * 28, H - i * 16), Color(0, 0, 0, 0.06), false, 14.0)


func draw_hud() -> void:
	draw_rect(Rect2(0, 0, W, 44), Color(0.04, 0.03, 0.08, 0.85))
	tx(Vector2(16, 30), "MALAM %d" % night, 22, Color(1, 0.85, 0.5))
	tx(Vector2(150, 30), clock_str(), 22)
	tx(Vector2(250, 30), rp(money), 22, Color(0.6, 1, 0.6))
	var shown: int = mini(handled + (1 if cust != null else 0), total)
	tx(Vector2(430, 30), "Pelanggan %d/%d" % [shown, total], 18, Color(0.8, 0.8, 0.95))
	tx(Vector2(600, 30), "Komplain:", 18, Color(0.9, 0.9, 0.9))
	for i in range(3):
		tx(Vector2(690 + i * 22, 30), "X", 20, Color(1, 0.3, 0.3) if i < complaints else Color(0.4, 0.4, 0.45))
	tx(Vector2(790, 30), "Waras:", 18, Color(0.9, 0.9, 0.9))
	for i in range(3):
		heart(Vector2(870 + i * 34, 17), 10.0, Color(0.95, 0.2, 0.3) if i < sanity else Color(0.3, 0.2, 0.25))
	tx(Vector2(985, 30), "Senter", 16, Color(1, 0.95, 0.7))
	draw_rect(Rect2(1045, 15, 110, 14), Color(0.15, 0.15, 0.2))
	draw_rect(Rect2(1045, 15, 110.0 * flash_e / FLASH_MAX, 14), Color(1, 0.9, 0.3))
	draw_rect(Rect2(1045, 15, 110, 14), Color(0.8, 0.8, 0.85), false, 1.5)
	if flash_on:
		tx(Vector2(1165, 30), "ON", 16, Color(1, 0.95, 0.4))


func draw_buttons() -> void:
	var fl := Color(0.85, 0.7, 0.2) if not flash_on else Color(1, 0.95, 0.4)
	rr(B_FLASH, fl.darkened(0.2), 10, fl.lightened(0.3), 3)
	tx(Vector2(B_FLASH.position.x, B_FLASH.position.y + 30), "SENTER [F]", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, B_FLASH.size.x)
	rr(B_REJECT, Color(0.65, 0.12, 0.12), 10, Color(1, 0.4, 0.4), 3)
	tx(Vector2(B_REJECT.position.x, B_REJECT.position.y + 30), "USIR [X]", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, B_REJECT.size.x)
	rr(B_NOTES, Color(0.55, 0.4, 0.22), 10, Color(0.9, 0.75, 0.45), 3)
	tx(Vector2(B_NOTES.position.x, B_NOTES.position.y + 30), "CATATAN [N]", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, B_NOTES.size.x)


func draw_hover_and_held() -> void:
	if show_notes:
		return
	for s in slots:
		var r: Rect2 = s["rect"]
		if r.has_point(mouse):
			draw_rect(r.grow(2), Color(1, 0.95, 0.4), false, 2.5)
			var p: Dictionary = PRODUCTS[s["id"]]
			var label: String = "%s - %s" % [p["name"], rp(p["price"])]
			var tw := ThemeDB.fallback_font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x
			var tp := Vector2(mouse.x + 16, mouse.y + 24)
			tp.x = minf(tp.x, W - tw - 24)
			rr(Rect2(tp.x - 8, tp.y - 18, tw + 16, 28), Color(0, 0, 0, 0.8), 6)
			tx(tp, label, 16, Color(1, 0.95, 0.7))
			break
	if held != "":
		draw_icon(Rect2(mouse.x - 22, mouse.y - 30, 44, 60), held)
		tx(mouse + Vector2(-80, 48), PRODUCTS[held]["name"], 15, Color(1, 0.95, 0.6), HORIZONTAL_ALIGNMENT_CENTER, 160)
		if cust != null and CUST_RECT.has_point(mouse):
			tx(mouse + Vector2(-80, 68), "klik untuk memberi", 14, Color(0.8, 1, 0.8), HORIZONTAL_ALIGNMENT_CENTER, 160)


func draw_toast() -> void:
	if toast_t <= 0.0:
		return
	var a: float = clampf(toast_t / 0.6, 0.0, 1.0)
	var f := ThemeDB.fallback_font
	var tw := f.get_string_size(toast_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x
	rr(Rect2(CX - tw * 0.5 - 18, 56, tw + 36, 38), Color(0, 0, 0, 0.75 * a), 10)
	tx(Vector2(CX - tw * 0.5, 82), toast_text, 20, Color(toast_col.r, toast_col.g, toast_col.b, a))


func notes_lines() -> Array:
	var lines: Array = []
	lines.append(["CARA MAIN", 1])
	lines.append(["- Pelanggan NORMAL: klik barang yang diminta, lalu klik pelanggan.", 0])
	lines.append(["- Ada tanda ANOMALI? Jangan kasih apa pun, tekan USIR [X].", 0])
	lines.append(["- SENTER [F]: sorot kepala pelanggan untuk lihat hal tersembunyi.", 0])
	lines.append(["- Klik kanan / Esc: batal pegang barang.", 0])
	lines.append(["", 0])
	lines.append(["TANDA-TANDA ANOMALI (terbuka bertahap)", 1])
	for k in ANOM:
		if int(ANOM[k]["night"]) <= night:
			lines.append(["- " + String(ANOM[k]["hint"]), 0])
	return lines


func draw_notes() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.6))
	var r := Rect2(230, 70, 820, 570)
	rr(r, Color(0.9, 0.82, 0.62), 14, Color(0.4, 0.26, 0.1), 5)
	tx(Vector2(r.position.x, r.position.y + 46), "BUKU CATATAN WARUNG", 30, Color(0.3, 0.15, 0.05), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, false)
	var y := r.position.y + 90
	for l in notes_lines():
		var head: bool = l[1] == 1
		tx(Vector2(r.position.x + 36, y), String(l[0]), 22 if head else 19, Color(0.55, 0.1, 0.1) if head else Color(0.2, 0.12, 0.06), HORIZONTAL_ALIGNMENT_LEFT, -1.0, false)
		y += 34 if head else 30
	tx(Vector2(r.position.x, r.end.y - 18), "(klik di mana saja untuk menutup)", 15, Color(0.4, 0.3, 0.2), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, false)


func draw_scare() -> void:
	var a: float = clampf(scare_t / 0.9, 0.0, 1.0)
	draw_rect(Rect2(0, 0, W, H), Color(0.22, 0, 0, 0.6 * a))
	if scare_t > 0.3:
		var k: float = 1.0 + (0.9 - scare_t) * 0.5
		draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.55))
		for sgn in [-1.0, 1.0]:
			ell(Vector2(CX + sgn * 170.0, 290), 80.0 * k, 55.0 * k, Color(0.02, 0, 0))
			draw_circle(Vector2(CX + sgn * 170.0, 290), 26.0 * k, Color(1, 0.05, 0.05))
		var pts := PackedVector2Array()
		for i in range(25):
			pts.append(Vector2(CX - 330 + i * 27.5, 440 + 130.0 * sin(PI * float(i) / 24.0) * k))
		draw_colored_polygon(pts, Color(0.03, 0, 0))
		for i in range(1, 24):
			var x: float = CX - 330 + i * 27.5
			var yb: float = 440 + 130.0 * sin(PI * float(i) / 24.0) * k
			draw_line(Vector2(x, 442), Vector2(x, yb - 4), Color(0.95, 0.95, 0.85), 3.0)


func draw_overlays() -> void:
	match state:
		S.TITLE:
			draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.01, 0.06, 0.78))
			ctext(210, "WARUNG TENGAH MALAM", 62, Color(1, 0.65, 0.2))
			ctext(262, "Jaga warung. Layani yang manusia. Usir yang bukan.", 24, Color(0.85, 0.8, 0.95))
			ctext(350, "Klik barang -> klik pelanggan untuk memberi.  USIR anomali dengan [X].", 20, Color(0.9, 0.9, 0.9))
			ctext(382, "SENTER [F]  |  CATATAN [N]  |  Klik kanan: batal pegang", 20, Color(0.9, 0.9, 0.9))
			ctext(414, "Bertahan 5 malam. Jangan sampai kewarasanmu habis.", 20, Color(1, 0.5, 0.5))
			var pulse: float = 0.6 + 0.4 * sin(time * 3.0)
			ctext(520, "- klik untuk mulai -", 26, Color(1, 1, 1, pulse))
		S.NIGHT_INTRO:
			draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.01, 0.06, 0.85))
			ctext(190, "MALAM KE-%d" % night, 56, Color(1, 0.65, 0.2))
			ctext(236, "22:00 - warung dibuka   |   %d pelanggan akan datang" % total, 22, Color(0.85, 0.8, 0.95))
			var y := 310.0
			var new_list: Array = []
			for k in ANOM:
				if int(ANOM[k]["night"]) == night:
					new_list.append(String(ANOM[k]["hint"]))
			if new_list.size() > 0:
				ctext(y, "Tanda anomali baru malam ini:", 24, Color(1, 0.45, 0.45))
				y += 40
				for h in new_list:
					ctext(y, "- " + String(h), 22, Color.WHITE)
					y += 34
			else:
				ctext(y, "Tidak ada tanda baru. Dua anomali bisa muncul bersamaan...", 22, Color(1, 0.45, 0.45))
			var pulse2: float = 0.6 + 0.4 * sin(time * 3.0)
			ctext(560, "- klik untuk membuka warung -", 24, Color(1, 1, 1, pulse2))
		S.NIGHT_END:
			draw_rect(Rect2(0, 0, W, H), Color(0.04, 0.03, 0.1, 0.85))
			ctext(210, "SUBUH TIBA...", 54, Color(1, 0.8, 0.4))
			ctext(262, "Malam ke-%d selesai." % night, 26)
			ctext(320, "Pendapatan malam ini: %s" % rp(money - night_start_money), 24, Color(0.6, 1, 0.6))
			ctext(356, "Total uang: %s" % rp(money), 24, Color(0.6, 1, 0.6))
			ctext(392, "Komplain: %d/3   |   Kewarasan: %d/3" % [complaints, sanity], 22, Color(0.9, 0.9, 0.95))
			ctext(520, "- klik untuk lanjut -", 24, Color(1, 1, 1, 0.6 + 0.4 * sin(time * 3.0)))
		S.GAME_OVER:
			draw_rect(Rect2(0, 0, W, H), Color(0.12, 0, 0, 0.88))
			ctext(240, "GAME OVER", 66, Color(0.95, 0.15, 0.15))
			ctext(310, over_reason, 24, Color(0.95, 0.85, 0.85))
			ctext(360, "Bertahan sampai malam ke-%d  |  Uang: %s" % [night, rp(money)], 22, Color(0.9, 0.9, 0.9))
			ctext(520, "- klik untuk kembali ke menu -", 22, Color(1, 1, 1, 0.6 + 0.4 * sin(time * 3.0)))
		S.WIN:
			draw_rect(Rect2(0, 0, W, H), Color(0.05, 0.04, 0.12, 0.88))
			ctext(230, "KAMU SELAMAT!", 62, Color(1, 0.8, 0.3))
			ctext(300, "Lima malam berlalu. Matahari akhirnya terbit di warungmu.", 24, Color(0.9, 0.9, 1.0))
			ctext(350, "Total uang: %s   |   Kewarasan tersisa: %d/3" % [rp(money), sanity], 24, Color(0.6, 1, 0.6))
			ctext(400, "...tapi tadi, siapa yang berdiri di pojok warung itu?", 20, Color(1, 0.5, 0.5))
			ctext(520, "- klik untuk kembali ke menu -", 22, Color(1, 1, 1, 0.6 + 0.4 * sin(time * 3.0)))


func _draw() -> void:
	if shake > 0.0:
		draw_set_transform(Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 12.0, 0.0, Vector2.ONE)
	draw_scene()
	draw_atmosphere()
	if state == S.PLAY or state == S.NIGHT_END:
		if cust != null and state == S.PLAY:
			draw_bubble(cust)
	if state == S.PLAY:
		draw_hover_and_held()
		draw_buttons()
	if state != S.TITLE:
		draw_hud()
	draw_toast()
	if state == S.PLAY and show_notes:
		draw_notes()
	draw_overlays()
	if scare_t > 0.0:
		draw_scare()
