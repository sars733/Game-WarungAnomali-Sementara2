# WARUNG TENGAH MALAM (Godot 4.x)

Game warung anomali bertema horor malam. Jaga warung, layani pelanggan normal, usir yang bukan manusia.

## Cara buka
1. Buka Godot 4.3+ (4.2 juga seharusnya bisa)
2. Import > pilih file `project.godot` di folder ini
3. Tekan F5 (Play)

## Cara main
- Klik barang di rak/kulkas/gantungan untuk memegangnya, lalu klik pelanggan untuk memberikannya.
- Pelanggan NORMAL: beri barang yang diminta -> dapat uang.
- Ada tanda ANOMALI: jangan beri apa pun, tekan USIR [X] -> bonus Rp2.000.
- Salah beri barang ke anomali, atau dibiarkan menatap terlalu lama -> kewarasan -1 (jumpscare).
- Salah usir pelanggan normal -> komplain +1 (3 komplain = game over) dan denda Rp3.000.
- SENTER [F]: sorot kepala pelanggan (baterai terbatas). CATATAN [N]: daftar tanda anomali.
- Klik kanan / Esc: batal memegang barang.
- 5 malam, tanda anomali baru terbuka tiap malam.

## Anomali
tinggi (leher panjang), senyum lebar, wajah polos, tanpa bayangan, bayangan bertanduk,
melayang, mata merah (senter), bayar daun/abu, permintaan aneh. Malam 5: bisa dua anomali sekaligus.

## Kustomisasi
Semua ada di `Game.gd`:
- `PRODUCTS` : daftar barang, harga, warna
- `ANOM` : daftar anomali dan malam kemunculannya
- `CREEPY` : dialog seram
- Visual digambar lewat `_draw()`; bisa diganti Sprite2D/TextureRect kalau mau pakai gambar sendiri.
